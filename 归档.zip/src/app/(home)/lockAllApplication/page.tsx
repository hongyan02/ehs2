"use client";

import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import CustomPagination from "@/components/CustomPagination";
import { useAllApplications } from "@/features/lock/lockApplication/query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import useInfoStore from "@/stores/useUserInfo";
import { Timeline } from "@/features/lock/components/Timeline";
import { LOCK_STATUS_TEXT, LOCK_STATUS_COLORS } from "@/config/lock-status";

interface Application {
  id: number;
  applicationCode: string;
  applicantName: string;
  applicantNo: string;
  department: string;
  phone: string;
  productionLine?: string | null;
  process?: string | null;
  team?: string | null;
  certificatePhoto?: string | null;
  status: string;
  currentApprovalLevel: number;
  applicationTime: string;
  leaderName?: string;
  leaderNo?: string;
  managerName?: string;
  managerNo?: string;
  safetyOfficerName?: string;
  safetyOfficerNo?: string;
  lockDetails?: Array<{
    id: number;
    lockType: string;
    specification?: string;
    quantity: number;
    purpose?: string;
  }>;
  approvalHistory?: Array<{
    id: number;
    approvalLevel: number;
    status: string;
    approver?: string;
    approverNo?: string;
    comment?: string;
    approvalTime?: string;
  }>;
  examResult?: {
    id: number;
    passed: boolean;
    score: number;
    examDate: string;
    screenshotUrl?: string;
  };
}

export default function LockAllApplicationPage() {
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const { permissions } = useInfoStore();

  const { data, isLoading, isError } = useAllApplications({
    page,
    pageSize,
  });

  const applicationList = data?.data ?? [];

  // Check if user has permission
  const hasPermission = permissions.includes("LOCK_VIEW_ALL");

  const handleViewDetails = (app: Application) => {
    setSelectedApp(app);
    setDetailOpen(true);
  };

  const getStatusBadge = (status: string) => {
    return (
      <Badge className={LOCK_STATUS_COLORS[status as keyof typeof LOCK_STATUS_COLORS] || "bg-gray-100"}>
        {LOCK_STATUS_TEXT[status as keyof typeof LOCK_STATUS_TEXT] || status}
      </Badge>
    );
  };

  if (!hasPermission) {
    return (
      <div className="p-6">

        <div className="text-center py-10 text-red-500">
          您没有权限查看此页面，请联系管理员开通权限
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">

      {isLoading ? (
        <div className="py-10 text-center">加载中...</div>
      ) : isError ? (
        <div className="py-10 text-center text-red-500">加载失败，请稍后重试</div>
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>申请单号</TableHead>
                <TableHead>申请人</TableHead>
                <TableHead>部门</TableHead>
                <TableHead>产线/工序/班组</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>申请时间</TableHead>
                <TableHead>操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {applicationList.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    暂无申请记录
                  </TableCell>
                </TableRow>
              ) : (
                applicationList.map((app: Application) => (
                  <TableRow key={app.id}>
                    <TableCell>{app.applicationCode}</TableCell>
                    <TableCell>{app.applicantName}</TableCell>
                    <TableCell>{app.department}</TableCell>
                    <TableCell>
                      {[app.productionLine, app.process, app.team].filter(Boolean).join(" / ") || "-"}
                    </TableCell>
                    <TableCell>{getStatusBadge(app.status)}</TableCell>
                    <TableCell>{app.applicationTime}</TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDetails(app)}
                      >
                        查看详情
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          <CustomPagination
            page={page}
            pageSize={pageSize}
            total={data?.total || 0}
            onChange={setPage}
            className="mt-4 justify-end"
          />
        </>
      )}

      {/* 详情对话框 */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>申请详情 - {selectedApp?.applicationCode}</DialogTitle>
          </DialogHeader>
          {selectedApp && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">申请人</label>
                  <p>{selectedApp.applicantName}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">申请人工号</label>
                  <p>{selectedApp.applicantNo}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">部门</label>
                  <p>{selectedApp.department}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">联系电话</label>
                  <p>{selectedApp.phone}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">所属产线</label>
                  <p>{selectedApp.productionLine || "-"}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">工序</label>
                  <p>{selectedApp.process || "-"}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">班组</label>
                  <p>{selectedApp.team || "-"}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">状态</label>
                  <p>{getStatusBadge(selectedApp.status)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">申请时间</label>
                  <p>{selectedApp.applicationTime}</p>
                </div>
              </div>

              {/* 上岗证照片 */}
              {selectedApp.certificatePhoto && (
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">上岗证照片</h3>
                  <img
                    src={selectedApp.certificatePhoto}
                    alt="上岗证"
                    className="w-40 h-40 object-cover rounded border"
                  />
                </div>
              )}

              {/* 审批人信息 */}
              <div className="border-t pt-4">
                <h3 className="font-medium mb-2">审批人信息</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-500">组长/主管：</span>
                    {selectedApp.leaderName} ({selectedApp.leaderNo || "-"})
                  </div>
                  <div>
                    <span className="text-gray-500">部门长：</span>
                    {selectedApp.managerName} ({selectedApp.managerNo || "-"})
                  </div>
                  <div>
                    <span className="text-gray-500">安环部：</span>
                    {selectedApp.safetyOfficerName} ({selectedApp.safetyOfficerNo || "-"})
                  </div>
                </div>
              </div>

              {/* 锁具明细 */}
              {selectedApp.lockDetails && selectedApp.lockDetails.length > 0 && (
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">锁具明细</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>锁具类型</TableHead>
                        <TableHead>规格型号</TableHead>
                        <TableHead>数量</TableHead>
                        <TableHead>用途说明</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedApp.lockDetails.map((detail) => (
                        <TableRow key={detail.id}>
                          <TableCell>{detail.lockType}</TableCell>
                          <TableCell>{detail.specification || "-"}</TableCell>
                          <TableCell>{detail.quantity}</TableCell>
                          <TableCell>{detail.purpose || "-"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* 流程进度时间轴 */}
              <div className="border-t pt-4">
                <h3 className="font-medium mb-4">流程进度</h3>
                <Timeline
                  approvalHistory={selectedApp.approvalHistory || []}
                  examResult={selectedApp.examResult || null}
                  status={selectedApp.status}
                  applicationTime={selectedApp.applicationTime}
                  currentApprovalLevel={selectedApp.currentApprovalLevel}
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
