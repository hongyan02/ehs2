import { CommandGroup, CommandItem, CommandList } from "./ui/command";
import { Command as CommandPrimitive } from "cmdk";
import {
  useState,
  useRef,
  useCallback,
  useEffect,
  type KeyboardEvent,
} from "react";

import { Skeleton } from "./ui/skeleton";

import { Check, Search } from "lucide-react";
import { cn } from "@/utils";

export type Option = Record<"value" | "label", string> & Record<string, string>;

//https://www.armand-salle.fr/post/autocomplete-select-shadcn-ui/
// options：候选项数据，格式为 { label, value, ... }，label 用于展示
// emptyMessage：没有匹配结果时展示的提示文案
// value：当前选中的 option（建议受控使用）
// onValueChange：选中变化时触发，返回完整 option
// isLoading：是否处于加载态，显示骨架屏
// disabled：禁用输入框和选择
// placeholder：输入框占位符
type AutoCompleteProps = {
  options: Option[];
  emptyMessage: string;
  value?: Option;
  onValueChange?: (value: Option) => void;
  isLoading?: boolean;
  disabled?: boolean;
  placeholder?: string;
};

export const AutoComplete = ({
  options,
  placeholder,
  emptyMessage,
  value,
  onValueChange,
  disabled,
  isLoading = false,
}: AutoCompleteProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const allowOpenOnFocusRef = useRef(false);

  const [isOpen, setOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState<string>(value?.label || "");
  const displayedInputValue = isEditing ? inputValue : (value?.label ?? "");

  const findOptionByLabel = useCallback(
    (label: string) => options.find((option) => option.label === label),
    [options],
  );

  const selectOption = useCallback(
    (option: Option) => {
      setIsEditing(false);
      setOpen(false);
      setInputValue(option.label);
      onValueChange?.(option);
    },
    [onValueChange],
  );

  const handleKeyDown = useCallback(
    (event: KeyboardEvent<HTMLDivElement>) => {
      const input = inputRef.current;
      if (!input) {
        return;
      }

      // Keep the options displayed when the user is typing
      if (!isOpen) {
        setOpen(true);
      }

      // This is not a default behaviour of the <input /> field
      if (event.key === "Enter" && input.value !== "") {
        const optionToSelect =
          findOptionByLabel(input.value) || { label: input.value, value: input.value };
        if (optionToSelect) {
          selectOption(optionToSelect);
        }
      }

      if (event.key === "Escape") {
        input.blur();
      }
    },
    [isOpen, findOptionByLabel, selectOption],
  );

  const handleBlur = useCallback(() => {
    setOpen(false);
    setIsEditing(false);
    const trimmed = inputValue.trim();
    if (!trimmed) {
      setInputValue(value?.label || "");
      return;
    }

    const existing = findOptionByLabel(trimmed);
    if (existing) {
      selectOption(existing);
      return;
    }
    if (value && value.label === trimmed) {
      setInputValue(value.label);
      return;
    }

    const customOption = { label: trimmed, value: trimmed };
    selectOption(customOption);
  }, [findOptionByLabel, inputValue, selectOption, value]);

  const handleSelectOption = useCallback(
    (selectedOption: Option) => {
      selectOption(selectedOption);

      // This is a hack to prevent the input from being focused after the user selects an option
      // We can call this hack: "The next tick"
      setTimeout(() => {
        inputRef?.current?.blur();
      }, 0);
    },
    [selectOption],
  );

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (document.activeElement === inputRef.current) {
        inputRef.current?.blur();
      }
      allowOpenOnFocusRef.current = true;
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <CommandPrimitive onKeyDown={handleKeyDown}>
      <div className="relative">
        <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          <Search className="h-4 w-4" />
        </span>
        <CommandPrimitive.Input
          ref={inputRef}
          value={displayedInputValue}
          onValueChange={
            isLoading
              ? undefined
              : (next) => {
                  setIsEditing(true);
                  setInputValue(next);
                }
          }
          onBlur={handleBlur}
          onFocus={(event) => {
            if (!allowOpenOnFocusRef.current) {
              event.target.blur();
              return;
            }
            setIsEditing(true);
            setInputValue(value?.label ?? "");
            setOpen(true);
          }}
          onPointerDown={() => {
            allowOpenOnFocusRef.current = true;
          }}
          placeholder={placeholder}
          disabled={disabled}
          data-autofocus="false"
          className={cn(
            "placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full rounded-md border bg-background px-9 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
            "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
            "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
          )}
        />
        <div
          className={cn(
            "absolute left-0 right-0 top-full z-10 mt-1 rounded-md border bg-popover text-popover-foreground shadow-md outline-none",
            isOpen ? "block" : "hidden",
          )}
        >
          <CommandList className="max-h-60 overflow-y-auto rounded-md">
            {isLoading ? (
              <CommandPrimitive.Loading>
                <div className="p-1">
                  <Skeleton className="h-8 w-full" />
                </div>
              </CommandPrimitive.Loading>
            ) : null}
            {options.length > 0 && !isLoading ? (
              <CommandGroup>
                {options.map((option) => {
                  const isSelected = value?.value === option.value;
                  return (
                    <CommandItem
                      key={option.value}
                      value={option.label}
                      onMouseDown={(event) => {
                        event.preventDefault();
                        event.stopPropagation();
                      }}
                      onSelect={() => handleSelectOption(option)}
                      className={cn(
                        "flex w-full items-center gap-2 px-3 py-2",
                        !isSelected ? "pl-9" : "pl-3",
                      )}
                    >
                      {isSelected ? <Check className="w-4" /> : null}
                      {option.label}
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            ) : null}
            {!isLoading ? (
              <CommandPrimitive.Empty className="select-none rounded-sm px-3 py-3 text-center text-sm">
                {emptyMessage}
              </CommandPrimitive.Empty>
            ) : null}
          </CommandList>
        </div>
      </div>
    </CommandPrimitive>
  );
};
