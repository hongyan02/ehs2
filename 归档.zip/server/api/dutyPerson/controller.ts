import { Context } from "hono";
import { z } from "zod";
import {
    getDutyPersons,
    getDutyPersonById,
    createDutyPerson,
    DutyPersonNoAlreadyExistsError,
    updateDutyPerson,
    deleteDutyPerson,
} from "./services";

const optionalText = z
    .string()
    .optional()
    .transform((val) => (val?.trim() ? val.trim() : undefined));

const getDutyPersonsSchema = z.object({
    page: z.string().optional().transform((val) => (val ? parseInt(val, 10) : 1)),
    pageSize: z
        .string()
        .optional()
        .transform((val) => (val ? parseInt(val, 10) : 10)),
    name: optionalText,
    no: optionalText,
});

const createDutyPersonSchema = z.object({
    name: z.string().min(1, "姓名不能为空"),
    no: z.string().min(1, "工号不能为空"),
    position: optionalText,
    phone: optionalText,
});

const updateDutyPersonSchema = z.object({
    name: z.string().min(1, "姓名不能为空").optional(),
    no: z.string().min(1, "工号不能为空").optional(),
    position: optionalText,
    phone: optionalText,
});

export const getDutyPersonsController = async (c: Context) => {
    try {
        const params = getDutyPersonsSchema.parse(c.req.query());
        const result = await getDutyPersons(params);
        return c.json({ success: true, data: result });
    } catch (error) {
        if (error instanceof z.ZodError) {
            return c.json({ success: false, message: error.issues }, 400);
        }
        console.error("getDutyPersonsController error:", error);
        return c.json({ success: false, message: "服务器错误" }, 500);
    }
};

export const getDutyPersonByIdController = async (c: Context) => {
    try {
        const id = parseInt(c.req.param("id") || "");
        if (Number.isNaN(id)) {
            return c.json({ success: false, message: "无效的ID" }, 400);
        }

        const result = await getDutyPersonById(id);
        if (!result) {
            return c.json({ success: false, message: "未找到该值班人员" }, 404);
        }

        return c.json({ success: true, data: result });
    } catch (error) {
        console.error("getDutyPersonByIdController error:", error);
        return c.json({ success: false, message: "服务器错误" }, 500);
    }
};

export const createDutyPersonController = async (c: Context) => {
    try {
        const body = await c.req.json();
        const validated = createDutyPersonSchema.parse(body);
        const payload = {
            ...validated,
            position: validated.position ?? null,
            phone: validated.phone ?? null,
        };
        const result = await createDutyPerson(payload);
        return c.json({ success: true, data: result }, 201);
    } catch (error) {
        if (error instanceof z.ZodError) {
            return c.json({ success: false, message: error.issues }, 400);
        }
        if (error instanceof DutyPersonNoAlreadyExistsError) {
            return c.json({ success: false, message: error.message }, 400);
        }
        console.error("createDutyPersonController error:", error);
        return c.json({ success: false, message: "服务器错误" }, 500);
    }
};

export const updateDutyPersonController = async (c: Context) => {
    try {
        const id = parseInt(c.req.param("id") || "");
        if (Number.isNaN(id)) {
            return c.json({ success: false, message: "无效的ID" }, 400);
        }

        const body = await c.req.json();
        const validated = updateDutyPersonSchema.parse(body);
        const existing = await getDutyPersonById(id);

        if (!existing) {
            return c.json({ success: false, message: "未找到该值班人员" }, 404);
        }

        const payload: Parameters<typeof updateDutyPerson>[0] = { id };

        if (validated.name !== undefined) payload.name = validated.name;
        if (validated.no !== undefined) payload.no = validated.no;
        if (validated.position !== undefined) payload.position = validated.position ?? null;
        if (validated.phone !== undefined) payload.phone = validated.phone ?? null;

        const result = await updateDutyPerson(payload);
        return c.json({ success: true, data: result });
    } catch (error) {
        if (error instanceof z.ZodError) {
            return c.json({ success: false, message: error.issues }, 400);
        }
        console.error("updateDutyPersonController error:", error);
        return c.json({ success: false, message: "服务器错误" }, 500);
    }
};

export const deleteDutyPersonController = async (c: Context) => {
    try {
        const id = parseInt(c.req.param("id") || "");
        if (Number.isNaN(id)) {
            return c.json({ success: false, message: "无效的ID" }, 400);
        }

        const existing = await getDutyPersonById(id);
        if (!existing) {
            return c.json({ success: false, message: "未找到该值班人员" }, 404);
        }

        await deleteDutyPerson(id);
        return c.json({ success: true, message: "删除成功" });
    } catch (error) {
        console.error("deleteDutyPersonController error:", error);
        return c.json({ success: false, message: "服务器错误" }, 500);
    }
};
